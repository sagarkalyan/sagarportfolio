from django.contrib import admin
from .models import myapp

# Register your models here.
admin.site.register(myapp)